<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $query = Invoice::with(['organization:id,name', 'subscription:id,plan']);

        if ($status = $request->query('status')) {
            $query->where('status', $status);
        }

        if ($orgId = $request->query('organization_id')) {
            $query->where('organization_id', $orgId);
        }

        if ($search = $request->query('search')) {
            $query->where(fn($q) => $q->where('invoice_number', 'like', "%{$search}%")
                                      ->orWhereHas('organization', fn($o) => $o->where('name', 'like', "%{$search}%")));
        }

        $invoices = $query->orderByDesc('created_at')->paginate($request->integer('per_page', 25));

        return response()->json($invoices);
    }

    public function show($id): JsonResponse
    {
        $invoice = Invoice::with(['organization', 'subscription.plan'])->findOrFail($id);
        
        $settings = \App\Models\GlobalSetting::whereIn('key', [
            'company_name', 'company_address', 'company_gst', 'invoice_prefix'
        ])->pluck('value', 'key')->toArray();

        return response()->json([
            'invoice' => $invoice,
            'company' => $settings,
        ]);
    }

    public function approve($id): JsonResponse
    {
        $invoice = Invoice::with('subscription')->findOrFail($id);

        if ($invoice->status !== 'open') {
            return response()->json(['message' => 'Only open invoices can be approved.'], 400);
        }

        $invoice->update([
            'status' => 'paid',
            'paid_at' => now(),
        ]);

        if ($invoice->subscription) {
            $invoice->subscription->update(['status' => 'active']);
        }

        try {
            if ($invoice->organization && $invoice->organization->billing_email) {
                \Illuminate\Support\Facades\Mail::raw("Your payment for Invoice #{$invoice->invoice_number} has been approved. Your subscription is now active.", function ($msg) use ($invoice) {
                    $msg->to($invoice->organization->billing_email)->subject('Subscription Activated');
                });
            }
        } catch (\Exception $e) {}

        return response()->json([
            'message' => 'Invoice approved successfully.',
            'invoice' => $invoice,
        ]);
    }

    public function deny($id): JsonResponse
    {
        $invoice = Invoice::with('subscription', 'organization')->findOrFail($id);

        if ($invoice->status !== 'open') {
            return response()->json(['message' => 'Only open invoices can be denied.'], 400);
        }

        $invoice->update([
            'status' => 'void',
        ]);

        if ($invoice->subscription) {
            $invoice->subscription->update(['status' => 'canceled']);
        }

        try {
            if ($invoice->organization && $invoice->organization->billing_email) {
                \Illuminate\Support\Facades\Mail::raw("Your recent payment for Invoice #{$invoice->invoice_number} could not be verified and has been denied. Your subscription was not activated. Please contact support if you believe this is a mistake.", function ($msg) use ($invoice) {
                    $msg->to($invoice->organization->billing_email)->subject('Subscription Payment Denied');
                });
            }
        } catch (\Exception $e) {}

        return response()->json([
            'message' => 'Invoice denied successfully.',
            'invoice' => $invoice,
        ]);
    }
}
