import { useEffect, useState, useCallback } from 'react';
import { adminApi } from '../api/admin';
import { useToast } from '../context/ToastContext';
import Skeleton from '../components/ui/Skeleton';
import Modal from '../components/ui/Modal';
import EmptyState from '../components/ui/EmptyState';
import { CreditCard } from 'lucide-react';
import { formatDateTime } from '../utils/format';

export default function AdminInvoices() {
  const toast = useToast();
  const [invoices, setInvoices] = useState(null);
  const [search, setSearch] = useState('');
  const [viewInvoice, setViewInvoice] = useState(null);

  const handleApprove = async (id) => {
    try {
      await adminApi.approveInvoice(id);
      toast.success('Invoice approved and subscription activated.');
      load();
    } catch (err) {
      toast.error('Failed to approve invoice.');
    }
  };

  const handleDeny = async (id) => {
    if (!window.confirm('Are you sure you want to deny this payment and void the invoice?')) return;
    try {
      await adminApi.denyInvoice(id);
      toast.success('Invoice denied and subscription canceled.');
      load();
    } catch (err) {
      toast.error('Failed to deny invoice.');
    }
  };

  const load = useCallback(async () => {
    try {
      const { data } = await adminApi.listInvoices({ search: search || undefined });
      setInvoices(data.data || []);
    } catch {
      toast.error('Could not load invoices.');
      setInvoices([]);
    }
  }, [search, toast]);

  useEffect(() => { load(); }, [load]);

  return (
    <>
      <div className="detail-header">
        <div className="detail-title">Invoices & Payments</div>
      </div>
      
      <div className="panel">
        <div className="panel-head">
          <div className="search-box" style={{ maxWidth: 240 }}>
            <input placeholder="Search invoices or orgs..." value={search} onChange={(e) => setSearch(e.target.value)} onBlur={load} onKeyDown={(e) => e.key === 'Enter' && load()} />
          </div>
        </div>
        
        {invoices === null ? (
          <div className="panel-body"><Skeleton height={200} /></div>
        ) : invoices.length === 0 ? (
          <div className="panel-body"><EmptyState icon={CreditCard} title="No invoices found" /></div>
        ) : (
          <table className="data-table">
            <thead>
              <tr>
                <th>Invoice #</th>
                <th>Organization</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Created</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {invoices.map((inv) => (
                <tr key={inv.id}>
                  <td style={{ fontFamily: 'var(--font-mono)' }}>{inv.invoice_number}</td>
                  <td style={{ fontWeight: 500 }}>{inv.organization?.name}</td>
                  <td>{inv.amount} {inv.currency?.toUpperCase()}</td>
                  <td>
                    <span className={`tag state-${inv.status === 'paid' ? 'resolved' : 'investigating'}`}>
                      {inv.status}
                    </span>
                  </td>
                  <td style={{ color: 'var(--white-40)' }}>{formatDateTime(inv.created_at)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 8 }}>
                      <button className="btn btn-ghost btn-sm" onClick={() => setViewInvoice(inv)}>
                        View
                      </button>
                      <button className="btn btn-ghost btn-sm" onClick={() => window.open(`/print/invoice/${inv.id}`, '_blank')}>
                        Download PDF
                      </button>
                      {inv.status === 'open' && (
                        <>
                          <button className="btn btn-primary btn-sm" onClick={() => handleApprove(inv.id)}>
                            Approve
                          </button>
                          <button className="btn btn-danger btn-sm" onClick={() => handleDeny(inv.id)} style={{ background: '#e11d48', color: '#fff', border: 'none' }}>
                            Deny
                          </button>
                        </>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {viewInvoice && (
        <Modal title="Invoice Details" onClose={() => setViewInvoice(null)}>
          <div style={{ marginBottom: 16 }}>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--white)' }}>Organization Details</h4>
            <div style={{ color: 'var(--white-80)' }}>Name: {viewInvoice.organization?.name}</div>
          </div>
          <div style={{ marginBottom: 16 }}>
            <h4 style={{ margin: '0 0 8px 0', color: 'var(--white)' }}>Payment Information</h4>
            <div style={{ color: 'var(--white-80)' }}>Amount: {viewInvoice.amount} {viewInvoice.currency?.toUpperCase()}</div>
            <div style={{ color: 'var(--white-80)' }}>Status: <span style={{ textTransform: 'uppercase' }}>{viewInvoice.status}</span></div>
            <div style={{ color: 'var(--white-80)' }}>Payment Method: {viewInvoice.subscription?.billing_provider || 'Manual/UPI'}</div>
            {viewInvoice.subscription?.billing_provider === 'manual' && viewInvoice.provider_invoice_id && (
              <div style={{ color: 'var(--white-80)', marginTop: 4, padding: '8px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px' }}>
                <strong>UTR / Transaction ID:</strong> {viewInvoice.provider_invoice_id}
              </div>
            )}
            {viewInvoice.receipt_path && (
              <div style={{ color: 'var(--white-80)', marginTop: 4, padding: '8px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px' }}>
                <strong>Payment Receipt:</strong> <a href={`/storage/${viewInvoice.receipt_path}`} target="_blank" rel="noreferrer" style={{ color: 'var(--primary-400)', textDecoration: 'underline' }}>View Uploaded Document</a>
              </div>
            )}
            <div style={{ color: 'var(--white-80)', marginTop: 8 }}>Created At: {formatDateTime(viewInvoice.created_at)}</div>
          </div>
        </Modal>
      )}
    </>
  );
}
