import { useEffect, useState } from 'react';
import { apiClient, apiErrorMessage } from '../api/client';
import { useToast } from '../context/ToastContext';
import Skeleton from '../components/ui/Skeleton';
import Modal from '../components/ui/Modal';
import { CreditCard, CheckCircle } from 'lucide-react';

export default function Billing() {
  const toast = useToast();
  const [plans, setPlans] = useState(null);
  const [currentSub, setCurrentSub] = useState(null);
  const [settings, setSettings] = useState(null);
  const [showCheckout, setShowCheckout] = useState(null); // stores the plan to checkout
  const [submitting, setSubmitting] = useState(false);
  const [billingCycle, setBillingCycle] = useState('monthly'); // 'monthly', 'half_yearly', 'yearly'
  const [showUpiFlow, setShowUpiFlow] = useState(false);
  const [utrNumber, setUtrNumber] = useState('');
  const [receiptFile, setReceiptFile] = useState(null);

  useEffect(() => {
    // Fetch public plans
    apiClient.get('/plans').then(({ data }) => setPlans(data)).catch(() => {});
    // Fetch current subscription
    apiClient.get('/v1/billing/current').then(({ data }) => setCurrentSub(data.subscription)).catch(() => {});
    // Fetch settings to get UPI info
    apiClient.get('/global-settings').then(({ data }) => setSettings(data)).catch(() => {});
  }, []);

  useEffect(() => {
    // Load Razorpay script dynamically
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.async = true;
    document.body.appendChild(script);
    return () => {
      document.body.removeChild(script);
    };
  }, []);

  async function handleSubscribe(method) {
    setSubmitting(true);
    try {
      let res;
      if (method === 'upi') {
        const formData = new FormData();
        formData.append('plan_key', showCheckout.key);
        formData.append('payment_method', method);
        formData.append('billing_cycle', billingCycle);
        formData.append('utr_number', utrNumber);
        if (receiptFile) formData.append('receipt_file', receiptFile);
        
        res = await apiClient.post('/v1/billing/subscribe', formData, {
          headers: { 'Content-Type': 'multipart/form-data' }
        });
      } else {
        res = await apiClient.post('/v1/billing/subscribe', {
          plan_key: showCheckout.key,
          payment_method: method,
          billing_cycle: billingCycle
        });
      }

      if (method === 'razorpay') {
        const { razorpay_order_id, razorpay_key } = res.data;
        if (!razorpay_key) throw new Error('Razorpay is not configured on the server.');

        const options = {
          key: razorpay_key,
          amount: showCheckout.price_inr_monthly * 100,
          currency: 'INR',
          name: 'NetOps Monitor',
          description: `Subscription to ${showCheckout.name}`,
          order_id: razorpay_order_id,
          handler: async function (response) {
            try {
              await apiClient.post('/v1/billing/razorpay/verify', {
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_order_id: response.razorpay_order_id,
                razorpay_signature: response.razorpay_signature
              });
              toast.success('Payment successful! Subscription activated.');
              setShowCheckout(null);
              apiClient.get('/v1/billing/current').then(({ data }) => setCurrentSub(data.subscription));
            } catch (err) {
              toast.error('Payment verification failed.');
            }
          },
          theme: { color: '#2E4FA3' }
        };
        const rzp = new window.Razorpay(options);
        rzp.on('payment.failed', function (response){
          toast.error('Payment failed. Invoice generated as pending.');
        });
        rzp.open();
      } else {
        toast.success(method === 'upi' ? 'Invoice generated! Pending admin approval.' : 'Subscription successful!');
        setShowCheckout(null);
        apiClient.get('/v1/billing/current').then(({ data }) => setCurrentSub(data.subscription));
      }
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <div className="detail-header">
        <div className="detail-title">Billing & Plans</div>
      </div>

      <div className="panel" style={{ marginBottom: 24 }}>
        <div className="panel-head">
          <div className="panel-title">Current Subscription</div>
        </div>
        <div className="panel-body">
          {currentSub ? (
            <div>
              <div style={{ fontSize: 20, fontWeight: 600, marginBottom: 8 }}>{currentSub.plan?.name || 'Unknown Plan'}</div>
              <div style={{ color: 'var(--white-60)' }}>
                Status: <span className={`tag state-${currentSub.status === 'active' ? 'resolved' : 'investigating'}`}>{currentSub.status === 'trialing' ? 'Pending Approval' : currentSub.status}</span>
              </div>
            </div>
          ) : (
            <div style={{ color: 'var(--white-60)' }}>You are currently on the Free plan.</div>
          )}
        </div>
      </div>

      <div style={{ display: 'flex', justifyContent: 'center', marginBottom: 32 }}>
        <div style={{ display: 'flex', background: 'var(--navy-800)', borderRadius: 24, padding: 4, border: '1px solid var(--navy-border)' }}>
          <button 
            className={`btn ${billingCycle === 'monthly' ? 'btn-primary' : 'btn-ghost'}`} 
            style={{ borderRadius: 20, padding: '6px 20px', minHeight: 36 }}
            onClick={() => setBillingCycle('monthly')}
          >
            Monthly
          </button>
          <button 
            className={`btn ${billingCycle === 'half_yearly' ? 'btn-primary' : 'btn-ghost'}`} 
            style={{ borderRadius: 20, padding: '6px 20px', minHeight: 36 }}
            onClick={() => setBillingCycle('half_yearly')}
          >
            Half-Yearly (Save 10%)
          </button>
          <button 
            className={`btn ${billingCycle === 'yearly' ? 'btn-primary' : 'btn-ghost'}`} 
            style={{ borderRadius: 20, padding: '6px 20px', minHeight: 36 }}
            onClick={() => setBillingCycle('yearly')}
          >
            Yearly (Save 20%)
          </button>
        </div>
      </div>

      <div className="pricing-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: 24 }}>
        {plans === null ? (
           <Skeleton height={300} />
        ) : (
          plans.map((plan) => {
            const price = billingCycle === 'monthly' ? plan.price_inr_monthly : (billingCycle === 'half_yearly' ? plan.price_inr_half_yearly : plan.price_inr_yearly);
            const isRecommended = plan.name.toLowerCase().includes('pro');
            
            return (
              <div key={plan.id} className="pricing-card" style={{ 
                background: isRecommended ? 'linear-gradient(180deg, var(--bg-2) 0%, var(--bg-1) 100%)' : 'var(--bg-2)', 
                padding: 32, 
                borderRadius: 16, 
                border: isRecommended ? '2px solid var(--primary-500)' : '1px solid var(--border)',
                position: 'relative',
                transform: isRecommended ? 'scale(1.02)' : 'none',
                boxShadow: isRecommended ? '0 12px 24px rgba(0,0,0,0.2)' : 'none',
                transition: 'transform 0.2s, box-shadow 0.2s'
              }}>
                {isRecommended && (
                  <div style={{ position: 'absolute', top: -14, left: '50%', transform: 'translateX(-50%)', background: 'var(--primary-500)', color: '#fff', padding: '4px 16px', borderRadius: 20, fontSize: 12, fontWeight: 700, letterSpacing: 0.5 }}>RECOMMENDED</div>
                )}
                <div className="plan-name" style={{ fontSize: 22, fontWeight: 700, color: isRecommended ? 'var(--primary-300)' : 'var(--white-90)' }}>{plan.name}</div>
                <div className="plan-price" style={{ fontSize: 48, fontWeight: 800, margin: '16px 0', display: 'flex', alignItems: 'baseline', gap: 4 }}>
                  ₹{price}
                  <span style={{ fontSize: 16, color: 'var(--white-60)', fontWeight: 500 }}>/{billingCycle === 'monthly' ? 'mo' : (billingCycle === 'half_yearly' ? '6mo' : 'yr')}</span>
                </div>
                
                <ul className="plan-features" style={{ listStyle: 'none', padding: 0, margin: '0 0 32px 0', flex: 1 }}>
                  <li style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}><CheckCircle size={18} color="var(--primary-400)" /> {plan.monitor_limit === -1 ? 'Unlimited' : plan.monitor_limit} Monitors</li>
                  <li style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}><CheckCircle size={18} color="var(--primary-400)" /> {plan.check_interval_min_seconds}s interval frequency</li>
                  <li style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}><CheckCircle size={18} color="var(--primary-400)" /> {plan.team_member_limit === -1 ? 'Unlimited' : plan.team_member_limit} Team members</li>
                  <li style={{ marginBottom: 16, display: 'flex', alignItems: 'center', gap: 10, fontSize: 15 }}><CheckCircle size={18} color="var(--primary-400)" /> {plan.status_page_limit === -1 ? 'Unlimited' : plan.status_page_limit} Status pages</li>
                </ul>

                {currentSub?.plan_id === plan.id || (price === 0 && (!currentSub || currentSub.status !== 'active')) ? (
                  <button className="btn btn-ghost" disabled style={{ width: '100%', padding: '12px', fontSize: 16, borderRadius: 8, background: 'rgba(255,255,255,0.05)', color: 'var(--white-60)' }}>Current Plan</button>
                ) : price === 0 ? (
                  <button className="btn btn-ghost" disabled style={{ width: '100%', padding: '12px', fontSize: 16, borderRadius: 8, opacity: 0.5 }}>Free Plan</button>
                ) : (
                  <button className={`btn ${isRecommended ? 'btn-primary' : 'btn-ghost'}`} style={{ width: '100%', padding: '12px', fontSize: 16, borderRadius: 8, background: isRecommended ? '' : 'var(--navy-800)' }} onClick={() => setShowCheckout(plan)}>
                    Subscribe Now
                  </button>
                )}
              </div>
            );
          })
        )}
      </div>

      {showCheckout && (
        <Modal title={`Subscribe to ${showCheckout.name}`} onClose={() => { setShowCheckout(null); setShowUpiFlow(false); setUtrNumber(''); setReceiptFile(null); }} footer={
          !showUpiFlow && <button className="btn btn-ghost" onClick={() => { setShowCheckout(null); setShowUpiFlow(false); setUtrNumber(''); setReceiptFile(null); }}>Cancel</button>
        }>
          <div style={{ marginBottom: 24, fontSize: 15, color: 'var(--white-80)' }}>
            You are subscribing to the <strong>{showCheckout.name}</strong> plan ({billingCycle}) for <strong>₹{billingCycle === 'monthly' ? showCheckout.price_inr_monthly : (billingCycle === 'half_yearly' ? showCheckout.price_inr_half_yearly : showCheckout.price_inr_yearly)}</strong>.
          </div>
          
          {showUpiFlow ? (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ textAlign: 'center', color: 'var(--white)' }}>
                Please scan the QR code below or use the UPI ID to pay.
              </div>
              
              {settings?.upi_qr_url && (
                <div style={{ display: 'flex', justifyContent: 'center' }}>
                  <img src={settings.upi_qr_url} alt="UPI QR" style={{ width: 200, height: 200, borderRadius: 8, background: '#fff', padding: 8 }} />
                </div>
              )}
              
              <div style={{ textAlign: 'center', fontSize: 18, fontWeight: 'bold', color: 'var(--primary-400)' }}>
                {settings?.upi_id || 'UPI ID not configured'}
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: 8, color: 'var(--white-80)', fontWeight: 500 }}>Transaction Receipt / UTR Number <span style={{color: '#f87171'}}>*</span></label>
                <input 
                  type="text" 
                  className="input" 
                  value={utrNumber} 
                  onChange={(e) => setUtrNumber(e.target.value)} 
                  placeholder="Enter 12-digit UTR or Transaction ID"
                  style={{ padding: '12px', fontSize: 16, background: 'rgba(255,255,255,0.03)', border: '1px solid var(--border)' }}
                />
              </div>

              <div>
                <label style={{ display: 'block', marginBottom: 8, color: 'var(--white-80)', fontWeight: 500 }}>Payment Screenshot / Receipt <span style={{color: '#f87171'}}>*</span></label>
                <div style={{ position: 'relative', border: '2px dashed var(--border)', borderRadius: 12, padding: '24px', textAlign: 'center', background: receiptFile ? 'rgba(56, 189, 248, 0.05)' : 'rgba(255,255,255,0.02)', transition: 'all 0.2s', cursor: 'pointer' }}>
                  <input 
                    type="file" 
                    accept="image/*"
                    onChange={(e) => setReceiptFile(e.target.files[0])}
                    style={{ position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', opacity: 0, cursor: 'pointer' }}
                  />
                  {receiptFile ? (
                    <div style={{ color: 'var(--primary-400)', fontWeight: 600 }}>
                      <CheckCircle size={24} style={{ marginBottom: 8 }} />
                      <div>{receiptFile.name}</div>
                      <div style={{ fontSize: 12, color: 'var(--white-60)', marginTop: 4 }}>Click to change file</div>
                    </div>
                  ) : (
                    <div style={{ color: 'var(--white-60)' }}>
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" style={{ marginBottom: 8, opacity: 0.8 }}><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path><polyline points="17 8 12 3 7 8"></polyline><line x1="12" y1="3" x2="12" y2="15"></line></svg>
                      <div style={{ fontWeight: 500, color: 'var(--white)' }}>Click or drag to upload receipt</div>
                      <div style={{ fontSize: 13, marginTop: 4 }}>PNG, JPG up to 5MB</div>
                    </div>
                  )}
                </div>
              </div>

              <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
                <button className="btn btn-ghost" style={{ flex: 1 }} onClick={() => setShowUpiFlow(false)}>Back</button>
                <button className="btn btn-primary" style={{ flex: 1 }} onClick={() => handleSubscribe('upi')} disabled={submitting || !utrNumber.trim() || !receiptFile}>Submit Payment</button>
              </div>
            </div>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
              <button className="btn btn-primary" onClick={() => handleSubscribe('razorpay')} disabled={submitting} style={{ display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'center', fontSize: 16, padding: '12px', background: 'linear-gradient(135deg, #0f2027, #203a43, #2c5364)', border: '1px solid #4ca1af' }}>
                <CreditCard size={20} /> Pay with Razorpay
              </button>
              <button className="btn btn-ghost" onClick={() => setShowUpiFlow(true)} disabled={submitting} style={{ display: 'flex', alignItems: 'center', gap: 12, justifyContent: 'center', background: 'var(--bg-2)' }}>
                 Pay Manually with UPI / QR
              </button>
            </div>
          )}
        </Modal>
      )}
    </>
  );
}
