<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Exception;

class DiagnosticToolController extends Controller
{
    private function validateTarget(Request $request)
    {
        $validated = $request->validate([
            'target' => 'required|string|max:255',
        ]);
        
        $target = trim($validated['target']);
        $target = preg_replace('#^https?://#', '', $target);
        $target = explode('/', $target)[0];

        if (!filter_var($target, FILTER_VALIDATE_IP) && !preg_match('/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/', $target)) {
            abort(422, 'Invalid target format. Must be a valid domain or IP address.');
        }

        return $target;
    }

    public function ping(Request $request)
    {
        $target = $this->validateTarget($request);
        $command = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? "ping -n 4 " . escapeshellarg($target) : "ping -c 4 " . escapeshellarg($target);
        
        exec($command . ' 2>&1', $output, $status);
        
        return response()->json([
            'target' => $target,
            'output' => implode("\n", $output),
            'success' => $status === 0
        ]);
    }

    public function traceroute(Request $request)
    {
        $target = $this->validateTarget($request);
        $command = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? "tracert -d -h 15 " . escapeshellarg($target) : "traceroute -m 15 -n " . escapeshellarg($target);
        
        exec($command . ' 2>&1', $output, $status);
        
        return response()->json([
            'target' => $target,
            'output' => implode("\n", $output),
            'success' => $status === 0
        ]);
    }

    public function dns(Request $request)
    {
        $target = $this->validateTarget($request);
        $types = [DNS_A, DNS_AAAA, DNS_CNAME, DNS_MX, DNS_TXT, DNS_NS];
        $results = [];
        
        foreach ($types as $type) {
            $records = @dns_get_record($target, $type);
            if ($records) {
                $results = array_merge($results, $records);
            }
        }
        
        return response()->json([
            'target' => $target,
            'records' => $results,
        ]);
    }

    public function port(Request $request)
    {
        $target = $this->validateTarget($request);
        $request->validate(['port' => 'required|integer|min:1|max:65535']);
        $port = $request->port;

        $fp = @fsockopen($target, $port, $errno, $errstr, 2);
        if ($fp) {
            fclose($fp);
            return response()->json(['target' => $target, 'port' => $port, 'status' => 'open']);
        }

        return response()->json(['target' => $target, 'port' => $port, 'status' => 'closed', 'error' => $errstr]);
    }

    public function whois(Request $request)
    {
        $target = $this->validateTarget($request);
        $command = (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') ? "echo Whois not supported natively on Windows" : "whois " . escapeshellarg($target);
        
        exec($command . ' 2>&1', $output, $status);
        
        return response()->json([
            'target' => $target,
            'output' => implode("\n", $output)
        ]);
    }

    public function ipinfo(Request $request)
    {
        $target = $this->validateTarget($request);
        // Ensure it's an IP
        if (!filter_var($target, FILTER_VALIDATE_IP)) {
            $target = gethostbyname($target);
        }

        try {
            $response = Http::timeout(5)->get("http://ip-api.com/json/{$target}");
            return response()->json($response->json());
        } catch (\Exception $e) {
            return response()->json(['error' => 'Failed to fetch IP info.'], 500);
        }
    }

    public function ssl(Request $request)
    {
        $target = $this->validateTarget($request);
        
        $context = stream_context_create([
            "ssl" => [
                "capture_peer_cert" => true,
                "verify_peer" => false,
                "verify_peer_name" => false,
            ]
        ]);

        try {
            $client = @stream_socket_client("ssl://{$target}:443", $errno, $errstr, 5, STREAM_CLIENT_CONNECT, $context);
            if (!$client) {
                return response()->json(['error' => "Could not connect to {$target} on port 443."], 400);
            }
            
            $params = stream_context_get_params($client);
            $certResource = $params["options"]["ssl"]["peer_certificate"];
            $certInfo = openssl_x509_parse($certResource);
            
            return response()->json([
                'target' => $target,
                'issuer' => $certInfo['issuer']['O'] ?? $certInfo['issuer']['CN'] ?? 'Unknown',
                'subject' => $certInfo['subject']['CN'] ?? 'Unknown',
                'valid_from' => date('Y-m-d H:i:s', $certInfo['validFrom_time_t']),
                'valid_to' => date('Y-m-d H:i:s', $certInfo['validTo_time_t']),
                'days_remaining' => floor(($certInfo['validTo_time_t'] - time()) / 86400),
                'extensions' => $certInfo['extensions'] ?? []
            ]);
        } catch (Exception $e) {
            return response()->json(['error' => 'Failed to fetch SSL certificate.'], 500);
        }
    }
    
    public function headers(Request $request)
    {
        $target = $this->validateTarget($request);
        try {
            $response = Http::timeout(5)->withOptions(['verify' => false])->head("https://{$target}");
            return response()->json([
                'target' => $target,
                'status' => $response->status(),
                'headers' => $response->headers(),
            ]);
        } catch (Exception $e) {
             try {
                 $response = Http::timeout(5)->head("http://{$target}");
                 return response()->json([
                    'target' => $target,
                    'status' => $response->status(),
                    'headers' => $response->headers(),
                 ]);
             } catch (Exception $e2) {
                 return response()->json(['error' => 'Failed to fetch headers.'], 500);
             }
        }
    }

    public function blacklist(Request $request)
    {
        $target = $this->validateTarget($request);
        if (!filter_var($target, FILTER_VALIDATE_IP)) {
            $target = gethostbyname($target);
        }
        
        $reverse_ip = implode('.', array_reverse(explode('.', $target)));
        $dnsbls = [
            'zen.spamhaus.org',
            'b.barracudacentral.org',
            'bl.spamcop.net',
            'cbl.abuseat.org',
            'dnsbl.sorbs.net'
        ];
        
        $results = [];
        $is_listed = false;
        
        foreach ($dnsbls as $dnsbl) {
            $lookup = $reverse_ip . '.' . $dnsbl;
            $record = @dns_get_record($lookup, DNS_A);
            $listed = !empty($record);
            if ($listed) $is_listed = true;
            
            $results[] = [
                'provider' => $dnsbl,
                'listed' => $listed,
                'details' => $listed ? $record[0]['ip'] : null
            ];
        }
        
        return response()->json([
            'target' => $target,
            'is_listed' => $is_listed,
            'results' => $results
        ]);
    }

    public function ipreputation(Request $request)
    {
        $target = $this->validateTarget($request);
        if (!filter_var($target, FILTER_VALIDATE_IP)) {
            $target = gethostbyname($target);
        }

        $reverse_ip = implode('.', array_reverse(explode('.', $target)));
        $lists = [
            'dnsbl.dronebl.org' => 'Drone/Botnet',
            'bl.blocklist.de' => 'Blocklist.de',
            'all.s5h.net' => 'S5H',
            'bl.spamcop.net' => 'Spamcop',
            'xbl.spamhaus.org' => 'Spamhaus XBL'
        ];
        
        $score = 100;
        $detections = [];

        foreach ($lists as $dnsbl => $type) {
            $lookup = $reverse_ip . '.' . $dnsbl;
            $record = @dns_get_record($lookup, DNS_A);
            if (!empty($record)) {
                $score -= 20;
                $detections[] = [
                    'source' => $type,
                    'list' => $dnsbl,
                    'record' => $record[0]['ip']
                ];
            }
        }
        
        $score = max(0, $score);
        $status = $score > 80 ? 'Clean' : ($score > 40 ? 'Suspicious' : 'Malicious');

        return response()->json([
            'target' => $target,
            'score' => $score,
            'status' => $status,
            'detections' => $detections
        ]);
    }

    public function snmpTest(Request $request)
    {
        $target = $this->validateTarget($request);
        $community = $request->input('community', 'public');
        $version = $request->input('version', '2c');
        
        // Timeout
        $timeout = 5; 
        
        $process = new \Symfony\Component\Process\Process([
            'snmpget', '-v', $version, '-c', $community, '-O', 'qv', '-t', (string)$timeout, '-r', '1', $target, 
            '1.3.6.1.2.1.1.3.0', // sysUpTime
            '1.3.6.1.2.1.1.1.0'  // sysDescr
        ]);
        
        $process->setTimeout($timeout + 5);
        $process->run();
        
        if (!$process->isSuccessful()) {
            return response()->json([
                'success' => false,
                'error' => 'SNMP error: ' . trim($process->getErrorOutput()),
                'target' => $target
            ], 400);
        }
        
        $output = explode("\n", trim($process->getOutput()));
        
        return response()->json([
            'success' => true,
            'target' => $target,
            'uptime' => $output[0] ?? 'Unknown',
            'description' => $output[1] ?? 'Unknown',
            'raw' => $process->getOutput()
        ]);
    }

    public function networkDiscovery(Request $request)
    {
        $validated = $request->validate([
            'cidr' => 'required|string',
            'communities' => 'nullable|string'
        ]);
        
        $cidr = $validated['cidr'];
        $communities = array_filter(array_map('trim', explode(',', $validated['communities'] ?? 'public')));
        if (empty($communities)) {
            $communities = ['public'];
        }
        
        // Fast nmap sweep
        $nmapCmd = "nmap -sn -oG - " . escapeshellarg($cidr);
        exec($nmapCmd, $nmapOutput, $nmapStatus);
        
        $discovered = [];
        
        if ($nmapStatus === 0) {
            foreach ($nmapOutput as $line) {
                // Host: 192.168.1.1 (router.lan)  Status: Up
                if (preg_match('/Host: ([\d\.]+) .*Status: Up/', $line, $matches)) {
                    $ip = $matches[1];
                    $discovered[] = ['ip' => $ip, 'status' => 'Up', 'snmp_status' => 'Unknown', 'description' => null, 'community' => null];
                }
            }
        } else {
            return response()->json(['error' => 'Nmap is required for network discovery but is not installed or failed.', 'details' => implode("\n", $nmapOutput)], 500);
        }
        
        // Now try SNMP on discovered IPs
        foreach ($discovered as &$host) {
            foreach ($communities as $comm) {
                $proc = new \Symfony\Component\Process\Process([
                    'snmpget', '-v', '2c', '-c', $comm, '-O', 'qv', '-t', '1', '-r', '0', $host['ip'], '1.3.6.1.2.1.1.1.0'
                ]);
                $proc->run();
                if ($proc->isSuccessful()) {
                    $host['snmp_status'] = 'Configured';
                    $host['description'] = trim($proc->getOutput());
                    $host['community'] = $comm;
                    break; // found the right community
                }
            }
        }
        
        return response()->json([
            'cidr' => $cidr,
            'discovered' => $discovered
        ]);
    }
}
