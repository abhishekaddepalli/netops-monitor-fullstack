<?php

namespace App\Services\Monitors;

use App\Models\Monitor;
use Symfony\Component\Process\Process;

class SnmpChecker implements MonitorCheckerInterface
{
    /**
     * Shells out to snmpget.
     * Config shape: { "community": "public", "version": "2c" }
     */
    public function check(Monitor $monitor): CheckResult
    {
        $config = $monitor->config ?? [];
        $community = $config['community'] ?? 'public';
        $version = $config['version'] ?? '2c';
        $target = $monitor->target;
        
        $timeout = $monitor->timeout_seconds ?? config('monitoring.default_timeout_seconds', 10);
        
        // Timeout for snmpget is in seconds.
        $start = microtime(true);
        
        // sysUpTime: 1.3.6.1.2.1.1.3.0
        // -O qv : Quick value output
        $process = new Process([
            'snmpget', '-v', $version, '-c', $community, '-O', 'qv', '-t', (string)$timeout, '-r', '1', $target, '1.3.6.1.2.1.1.3.0'
        ]);
        
        $process->setTimeout($timeout + 5);
        
        try {
            $process->run();
        } catch (\Exception $e) {
            return CheckResult::down($e->getMessage(), null, null);
        }

        $durationMs = (int) round((microtime(true) - $start) * 1000);

        if (!$process->isSuccessful()) {
            return CheckResult::down(
                'SNMP error: ' . trim($process->getErrorOutput()),
                null,
                $durationMs,
                ['output' => $process->getOutput()]
            );
        }

        $output = trim($process->getOutput());
        
        return CheckResult::up(
            $durationMs,
            200,
            ['uptime' => $output]
        );
    }
}
