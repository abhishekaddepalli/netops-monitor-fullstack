<?php

namespace App\Services\Monitors;

use App\Models\Monitor;
use Symfony\Component\Process\Process;

class SnmpChecker implements MonitorCheckerInterface
{
    /**
     * Shells out to snmpget.
     * Config shape: { "community": "public", "version": "2c" }
     */
    public function check(Monitor $monitor): CheckResult
    {
        $config = $monitor->config ?? [];
        $user = $config['user'] ?? '';
        $authPass = $config['auth_pass'] ?? '';
        $privPass = $config['priv_pass'] ?? '';
        $target = $monitor->target;
        
        $timeout = $monitor->timeout_seconds ?? config('monitoring.default_timeout_seconds', 10);
        
        $args = ['snmpget', '-v', $version];
        if ($version === '3') {
            $secLevel = 'noAuthNoPriv';
            $args[] = '-u'; $args[] = $user;
            if (!empty($authPass)) {
                $secLevel = empty($privPass) ? 'authNoPriv' : 'authPriv';
                $args[] = '-a'; $args[] = 'SHA';
                $args[] = '-A'; $args[] = $authPass;
            }
            if (!empty($privPass)) {
                $args[] = '-x'; $args[] = 'AES';
                $args[] = '-X'; $args[] = $privPass;
            }
            $args[] = '-l'; $args[] = $secLevel;
        } else {
            $args[] = '-c'; $args[] = $community;
        }
        
        $baseArgs = $args;
        
        // Timeout for snmpget is in seconds.
        $start = microtime(true);
        
        // sysUpTime: 1.3.6.1.2.1.1.3.0
        // -O qv : Quick value output
        $process = new Process(array_merge($args, [
            '-O', 'qv', '-t', (string)$timeout, '-r', '1', $target, '1.3.6.1.2.1.1.3.0'
        ]));
        
        $process->setTimeout($timeout + 5);
        
        try {
            $process->run();
        } catch (\Exception $e) {
            return CheckResult::down($e->getMessage(), null, null);
        }

        $durationMs = (int) round((microtime(true) - $start) * 1000);

        if (!$process->isSuccessful()) {
            return CheckResult::down(
                'SNMP error: ' . trim($process->getErrorOutput()),
                null,
                $durationMs,
                ['output' => $process->getOutput()]
            );
        }

        $output = trim($process->getOutput());
        
        // Attempt to fetch basic CPU/RAM using UCD-SNMP-MIB
        // ssCpuIdle.0, memTotalReal.0, memAvailReal.0
        $metricProc = new Process(array_merge($baseArgs, [
            '-O', 'qv', '-t', '1', '-r', '0', $target,
            '1.3.6.1.4.1.2021.11.11.0', // ssCpuIdle
            '1.3.6.1.4.1.2021.4.5.0',   // memTotalReal
            '1.3.6.1.4.1.2021.4.6.0'    // memAvailReal
        ]));
        $metricProc->run();
        
        if ($metricProc->isSuccessful()) {
            $vals = explode("\n", trim($metricProc->getOutput()));
            if (count($vals) >= 3 && is_numeric($vals[0]) && is_numeric($vals[1]) && is_numeric($vals[2]) && $vals[1] > 0) {
                $idle = (float)$vals[0];
                $total = (float)$vals[1];
                $avail = (float)$vals[2];
                $cpu_usage = max(0, min(100, 100 - $idle));
                $ram_usage = max(0, min(100, (($total - $avail) / $total) * 100));
                
                \App\Models\ServerMetric::create([
                    'monitor_id' => $monitor->id,
                    'cpu_usage_pct' => $cpu_usage,
                    'ram_usage_pct' => $ram_usage,
                    'disk_usage_pct' => 0,
                    'interfaces' => [],
                ]);
            }
        }
        
        return CheckResult::up(
            $durationMs,
            200,
            ['uptime' => $output]
        );
    }
}
